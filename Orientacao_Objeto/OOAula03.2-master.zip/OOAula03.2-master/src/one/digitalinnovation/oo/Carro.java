package one.digitalinnovation.oo;

/**
 * Classe de exemplo para o exercício da Aula 2 de Orientação a Objetos.
 */
class Carro {

    String cor;
    String modelo;
    int capacidadeTanque;


}
