package one.digitalinnovation.oo;

/**
 * Classe de exemplo para o exercício da Aula 4 de Orientação a Objetos.
 */
class ClasseFilha1 extends ClasseMae {

    @Override
    void metodo1() {
        System.out.println("Método 1 da Classe Filha 1");
    }

}