package one.digitalinnovation.oo;

/**
 * Classe de exemplo para o exercício da Aula 4 de Orientação a Objetos.
 */
class ClasseFilha2  extends ClasseMae {

    @Override
    void metodo1() {
        System.out.println("Método 1 da Classe Filha 2");
    }

    @Override
    void metodo2() {
        System.out.println("Método 2 da Classe Filha 2");
    }

}