package one.digitalinnovation.oo;

/**
 * Classe de exemplo para o exercício da Aula 4 de Orientação a Objetos.
 */
class ClasseMae {

    void metodo1() {
        System.out.println("Método 1 da Classe Mãe");
    }

    void metodo2() {
        System.out.println("Método 2 da Classe Mãe");
    }
}