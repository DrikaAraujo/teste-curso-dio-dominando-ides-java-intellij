package one.digitalinnovation.oo;

/**
 * Classe de exemplo para o exercício da Aula 3 de Orientação a Objetos.
 */
class Carro {

}
