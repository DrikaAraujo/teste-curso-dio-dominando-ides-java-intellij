package outro.pacote;

import one.digitalinnovation.oo.Classe1;

/**
 * Classe de exemplo para o exercício da Aula 5 de Orientação a Objetos.
 */
class Classe4 {

    Classe1 classe1;

    void metodo() {

        //atributo3

        //metodo3

    }

}