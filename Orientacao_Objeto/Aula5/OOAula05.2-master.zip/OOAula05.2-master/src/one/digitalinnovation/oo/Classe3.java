package one.digitalinnovation.oo;

/**
 * Classe de exemplo para o exercício da Aula 5 de Orientação a Objetos.
 */
class Classe3 {

    Classe1 classe1;

    void metodo() {

        //atributo2 e 3

        //metodo2 e 3

    }


    
}