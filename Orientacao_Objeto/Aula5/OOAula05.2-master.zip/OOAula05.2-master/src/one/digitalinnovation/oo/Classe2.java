package one.digitalinnovation.oo;

/**
 * Classe de exemplo para o exercício da Aula 5 de Orientação a Objetos.
 */
class Classe2 extends Classe1 {

    //Atributos próprios

    void metodo() {

        //atributo2 e 3
        
    }

    //metodo2 e 3

}