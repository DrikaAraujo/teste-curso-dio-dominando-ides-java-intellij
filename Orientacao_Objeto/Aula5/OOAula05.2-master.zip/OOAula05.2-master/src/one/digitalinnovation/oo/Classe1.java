package one.digitalinnovation.oo;

/**
 * Classe de exemplo para o exercício da Aula 5 de Orientação a Objetos.
 */
public class Classe1 {

    private String atributo1;

    protected String atributo2;

    public String atributo3;

    private void metodo1() {

    }

    protected void metodo2() {

    }

    public void metodo3() {

    }

}