package qualquer.outro.pacote;

import one.digitalinnovation.oo.outropacote.ExemploPacotes1;

/**
 * Classe de exemplo para o exercício da Aula 5 de Orientação a Objetos.
 */
class ExemplosPacotes3 {

    ExemploPacotes1 exemploPacotes1;
}
