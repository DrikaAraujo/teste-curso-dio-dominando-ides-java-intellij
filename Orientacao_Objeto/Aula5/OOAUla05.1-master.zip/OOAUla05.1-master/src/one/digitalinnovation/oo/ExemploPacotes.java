package one.digitalinnovation.oo;

import one.digitalinnovation.oo.outropacote.ExemploPacotes1;

/**
 * Classe de exemplo para o exercício da Aula 5 de Orientação a Objetos.
 */
class ExemploPacotes {

    ExemploPacotes1 outroPacote;
}
