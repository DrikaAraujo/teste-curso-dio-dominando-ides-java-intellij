package one.digitalinnovation.oo.outropacote;

/**
 * Classe de exemplo para o exercício da Aula 5 de Orientação a Objetos.
 */
class ExemploPacotes2 {

    ExemploPacotes2 exemploPacotes2;

}
